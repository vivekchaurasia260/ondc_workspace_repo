package com.kpmg.poc.ondc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OndcApplication {

	public static void main(String[] args) {
		SpringApplication.run(OndcApplication.class, args);
	}

}
